/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadora;

import java.util.Scanner;

/**
 *
 * @author alunolab08
 */
public class Calculadora {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int opcao = 0;
        float numero1, numero2;
        float resultado = 0;
        while(opcao != 5)
        {
        System.out.println("\t---------------------");
        System.out.println("\t Menu de operações");
        System.out.println("\t---------------------");
        System.out.println("\t[1] Adição (+)\n");
        System.out.println("\t[2] Subtração (-)\n");
        System.out.println("\t[3] Multiplicação (*)\n");
        System.out.println("\t[4] Divisão (/)\n");
        System.out.println("\t[5] Sair \n");
        
        opcao = scan.nextInt();
        System.out.printf("A opção escolhida foi: %d \n", opcao);
        
        //Verificação//
        /*
        if(opcao > 4 || opcao < 0)
        {
            System.out.println("Opção inválida!");
        }
        
        else if(opcao == 5)
        {
            System.out.println("Saindo...");
        }
        */
       
        
        switch(opcao)
        {
        
            case 1: System.out.println("---------------------");
            System.out.println(" Adição (+)\n");
            System.out.println("---------------------");
            System.out.println("Informe um numero:\n");
            numero1 = scan.nextFloat();
            
            System.out.println("Informe mais um numero:\n");
            numero2 = scan.nextFloat();
            
            resultado = numero1 + numero2;
            System.out.printf("O resultado é %.2f\n", resultado);
            resultado = 0;
            break;
            
            case 2:System.out.println("\t Subtração (-)\n");
            System.out.println("\t Informe um numero:\n");
            numero1 = scan.nextFloat();
            
            System.out.println("\t Informe mais um numero:\n");
            numero2 = scan.nextFloat();
            
            resultado = numero1 - numero2;
            System.out.printf("\t O resultado é %.2f\n", resultado);
            resultado = 0;
            break;
            
            case 3:System.out.println("\t Multiplicação (*)\n");
            System.out.println("\t Informe um numero:\n");
            numero1 = scan.nextFloat();
            
            System.out.println("\t Informe mais um numero:\n");
            numero2 = scan.nextFloat();
            
            resultado = numero1 * numero2;
            System.out.printf("\t O resultado é %.2f\n", resultado);
            resultado = 0;
            break;
            
            case 4: System.out.println("\t Divisão (/)\n");
            System.out.println("Informe um numero:\n");
            numero1 = scan.nextFloat();
            
            System.out.println("Informe mais um numero:\n");
            numero2 = scan.nextFloat();
            
            resultado = (numero1 / numero2);
            System.out.printf("\t O resultado é %.2f\n", resultado);
            resultado = 0;
            break;
            
            case 5: System.out.println("Saindo...");
            break;
            
            
            
            default:
                System.err.println("Valor invalido\n");
                break;
                
        }
        
        }
    }
}
    

