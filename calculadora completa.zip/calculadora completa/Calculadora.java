/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadora;

import java.util.Scanner;

/**
 *
 * @author alunolab08
 */
public class Calculadora {
    public static float somar(float numero1, float numero2)
    {
        return numero1 + numero2;
    }
    public static float subtrair(float numero1, float numero2)
    {
        return numero1 - numero2;
    }
    public static float multi(float numero1, float numero2)
    {
        return (numero1 * numero2);
    }
    public static float divi(float numero1, float numero2)
    {
        return numero1 / numero2;
    }
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int opcao = 0;
        float numero1, numero2;
        float resultado = 0;
        while(opcao != 5)
        {
        System.out.println("\t---------------------");
        System.out.println("\t Menu de operações");
        System.out.println("\t---------------------");
        System.out.println("\t[1] Adição (+)\n");
        System.out.println("\t[2] Subtração (-)\n");
        System.out.println("\t[3] Multiplicação (*)\n");
        System.out.println("\t[4] Divisão (/)\n");
        System.out.println("\t[5] Sair \n");
        
        opcao = scan.nextInt();
        System.out.printf("A opção escolhida foi: %d", opcao);
        
        //Verificação de erro simples//
        /*
        if(opcao > 4 || opcao < 0)
        {
            System.out.println("Opção inválida!");
        }
        
        else if(opcao == 5)
        {
            System.out.println("Saindo...");
        }
        */
       
        
        switch(opcao)
        {
        
            case 1: System.out.println("---------------------");
            System.out.println(" Adição (+)\n");
            System.out.println("---------------------");
            System.out.println("Informe um numero:");
            numero1 = scan.nextFloat();
            
            System.out.println("Informe mais um numero:");
            numero2 = scan.nextFloat();
            
            resultado = somar(numero1, numero2);
            System.out.printf("O resultado é %.2f\n", resultado);
            resultado = 0;
            break;
            
            case 2:System.out.println("\t Subtração (-)\n");
            System.out.println("Informe um numero:");
            numero1 = scan.nextFloat();
            
            System.out.println("Informe mais um numero:");
            numero2 = scan.nextFloat();
            
            resultado = subtrair(numero1, numero2);
            System.out.printf("O resultado é %.2f", resultado);
            resultado = 0;
            break;
            
            case 3:System.out.println("\t Multiplicação (*)\n");
            System.out.println("Informe um numero:");
            numero1 = scan.nextFloat();
            
            System.out.println("Informe mais um numero:");
            numero2 = scan.nextFloat();
            
            resultado = multi(numero1, numero2);
            System.out.printf("O resultado é %.2f", resultado);
            resultado = 0;
            break;
            
            case 4: System.out.println("\t Divisão (/)\n");
            System.out.println("Informe um numero:");
            numero1 = scan.nextFloat();
            
            System.out.println("Informe mais um numero:");
            numero2 = scan.nextFloat();
            
            resultado = divi(numero1, numero2);
            System.out.printf("O resultado é %.2f", resultado);
            resultado = 0;
            break;
            
            case 5: System.out.println("Saindo...");
            break;
            
            
            
            default:
                System.err.println("Valor invalido\n");
                break;
                
        }
        
        }
    }
}
    

